﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartsSample.Models
{
    public class BarData
    {
        public string Category { get; set; }
        public double Value { get; set; }
    }
}
