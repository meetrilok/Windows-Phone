﻿using Microsoft.Phone.Controls;
using SQLiteDemo.ViewModels;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace MSOpenTechSQLiteDemo.Views
{
    public partial class MainPage : PhoneApplicationPage
    {
        CustomersViewModel viewModel;
        DateTime timestamp = DateTime.MinValue;

        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (viewModel != null && timestamp >= viewModel.Timestamp)
                return;

            LoadData();

            timestamp = DateTime.Now;
        }

        private void LoadData()
        {
            viewModel = CustomersViewModel.GetDefault();
            CustomersList.ItemsSource = viewModel.GetAllItems();
        }

        private void AddCustomerAppBarButton_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/CustomerEditView.xaml?NEW=true", UriKind.Relative));
        }

        private void CustomersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CustomersList.SelectedItem != null)
            {
                NavigationService.Navigate(new Uri("/Views/CustomerProjectsView.xaml?ID="
                    + ((Customer)CustomersList.SelectedItem).Id, UriKind.Relative));

                CustomersList.SelectedItem = null;
            }
        }

        private async void ResetDataMenuItem_Click(object sender, EventArgs e)
        {
            ApplicationBar.IsMenuEnabled = false;

            CustomersList.ItemsSource = null;
            await SQLiteDemo.CreateDatabase.ResetDataAsync(App.conn);
            LoadData();

            ApplicationBar.IsMenuEnabled = true;
        }
    }
}