﻿using Microsoft.Phone.Controls;
using SQLiteDemo.ViewModels;
using SQLitePCL;
using System;
using System.Windows;
using System.Windows.Navigation;

namespace MSOpenTechSQLiteDemo.Views
{
    public partial class ProjectView : PhoneApplicationPage
    {
        private Project viewModel;

        public ProjectView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string value;
            if (!NavigationContext.QueryString.TryGetValue("ID", out value))
                throw new InvalidOperationException("Must supply an Id");

            try
            {
                viewModel = ProjectsViewModel.GetDefault().GetItem(Int32.Parse(value));
                this.DataContext = viewModel;
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Can't find that item: " + ex.Message);
            }
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/ProjectEditView.xaml?ID=" + viewModel.Id, UriKind.Relative));
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                ProjectsViewModel.GetDefault().DeleteItem(viewModel.Id);
                if (NavigationService.CanGoBack)
                    NavigationService.GoBack();
                else
                    DataContext = null;
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Can't delete that item: " + ex.Message);
            }
        }
    }
}