﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using SQLiteDemo.ViewModels;
using SQLitePCL;

namespace MSOpenTechSQLiteDemo.Views
{
    public partial class CustomerProjectsView : PhoneApplicationPage
    {
        private Customer customer;
        private ProjectsViewModel projectsViewModel;
        DateTime timestamp = DateTime.MinValue;

        public CustomerProjectsView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (projectsViewModel != null && timestamp >= projectsViewModel.Timestamp && timestamp >= CustomersViewModel.GetDefault().Timestamp)
                return;

            string value;
            if (!NavigationContext.QueryString.TryGetValue("ID", out value))
                throw new InvalidOperationException("Must supply an Id");

            try
            {
                customer = CustomersViewModel.GetDefault().GetItem(Int32.Parse(value));
                this.DataContext = customer;

                try
                {
                    projectsViewModel = ProjectsViewModel.GetForCustomerId(customer.Id);
                    ProjectsList.ItemsSource = projectsViewModel.GetAllItems();
                    ProjectsList.SelectedItem = null;
                }
                catch (SQLiteException ex)
                {
                    MessageBox.Show("Can't get projects for this customer: " + ex.Message);
                }
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Can't get details for this customer: " + ex.Message);
            }

            timestamp = DateTime.Now;
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/CustomerEditView.xaml?ID=" + customer.Id, UriKind.Relative));
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                CustomersViewModel.GetDefault().DeleteItem(customer.Id);
                if (NavigationService.CanGoBack)
                    NavigationService.GoBack();
                else
                    DataContext = null;
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Can't delete that item: " + ex.Message);
            }
        }

        private void Pivot_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DetailsPivot.SelectedIndex != 0)
            {
                (this.ApplicationBar.Buttons[0] as ApplicationBarIconButton).IsEnabled = false;
                (this.ApplicationBar.Buttons[1] as ApplicationBarIconButton).IsEnabled = false;
                (this.ApplicationBar.Buttons[2] as ApplicationBarIconButton).IsEnabled = true;
            }
            else
            {
                (this.ApplicationBar.Buttons[0] as ApplicationBarIconButton).IsEnabled = true;
                (this.ApplicationBar.Buttons[1] as ApplicationBarIconButton).IsEnabled = true;
                (this.ApplicationBar.Buttons[2] as ApplicationBarIconButton).IsEnabled = false;
            }
        }

        private void ProjectsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ProjectsList.SelectedItem != null)
            {
                NavigationService.Navigate(new Uri("/Views/ProjectView.xaml?ID="
                    + ((Project)ProjectsList.SelectedItem).Id, UriKind.Relative));

                ProjectsList.SelectedItem = null;
            }
        }

        private void AddProjectButton_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/ProjectEditView.xaml?NEW=true&CUSTOMERID=" + customer.Id, UriKind.Relative));
        }
    }
}