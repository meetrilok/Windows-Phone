﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using SQLiteDemo.ViewModels;
using MSOpenTechSQLiteDemo.Resources;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using SQLitePCL;

namespace MSOpenTechSQLiteDemo.Views
{
    public partial class ProjectEditView : PhoneApplicationPage
    {
        private Project viewModel;

        public ProjectEditView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (viewModel != null)
                return;

            string value;
            if (NavigationContext.QueryString.TryGetValue("NEW", out value))
            {
                SetTitleForNew();
                viewModel = new Project(Int32.Parse(NavigationContext.QueryString["CUSTOMERID"]));
            }
            else if (NavigationContext.QueryString.TryGetValue("ID", out value))
            {
                SetTitleForEdit();
                viewModel = ProjectsViewModel.GetDefault().GetItem(Int32.Parse(value));
            }

            DataContext = viewModel;
        }

        private void SetTitleForEdit()
        {
            PageTitle.Text = AppResources.EditProjectPageTitle;
        }

        private void SetTitleForNew()
        {
            PageTitle.Text = AppResources.NewProjectPageTitle;
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            ForceTextBoxDataBindingUpdate();

            try
            {
                if (viewModel.IsNew)
                    ProjectsViewModel.GetDefault().InsertItem(viewModel);
                else if (viewModel.IsDirty)
                    ProjectsViewModel.GetDefault().UpdateItem(viewModel.Id, viewModel);

                if (NavigationService.CanGoBack)
                    NavigationService.GoBack();
                else
                    DataContext = null;
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Can't save that item: " + ex.Message);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            if (NavigationService.CanGoBack)
                NavigationService.GoBack();
            else
                DataContext = null;
        }

        private void ForceTextBoxDataBindingUpdate()
        {
            object focusObj = System.Windows.Input.FocusManager.GetFocusedElement();

            if (focusObj != null && focusObj is TextBox)
            {
                var binding = (focusObj as TextBox).GetBindingExpression(TextBox.TextProperty);
                binding.UpdateSource();
            }
        }
    }
}