﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using MSOpenTechSQLiteDemo.Resources;
using SQLiteDemo.ViewModels;
using SQLitePCL;

namespace MSOpenTechSQLiteDemo.Views
{
    public partial class CustomerEditView : PhoneApplicationPage
    {
        private Customer viewModel;
        DateTime timestamp = DateTime.MinValue;

        public CustomerEditView()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (viewModel != null && timestamp >= ProjectsViewModel.GetDefault().Timestamp)
                return;

            string value;
            if (NavigationContext.QueryString.TryGetValue("NEW", out value))
                InitForNewCustomer();
            else if (NavigationContext.QueryString.TryGetValue("ID", out value))
                InitForEditCustomer(Int32.Parse(value));

            this.DataContext = viewModel;
        }

        private void InitForEditCustomer(int ID)
        {
            this.PageTitle.Text = AppResources.EditCustomerPageTitle;
            viewModel = CustomersViewModel.GetDefault().GetItem(ID);
        }

        private void InitForNewCustomer()
        {
            this.PageTitle.Text = AppResources.NewCustomerPageTitle;
            viewModel = new Customer();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            ForceTextBoxDataBindingUpdate();

            try
            {
                if (viewModel.IsNew)
                    CustomersViewModel.GetDefault().InsertItem(viewModel);
                else if (viewModel.IsDirty)
                    CustomersViewModel.GetDefault().UpdateItem(viewModel.Id, viewModel);

                if (NavigationService.CanGoBack)
                    NavigationService.GoBack();
                else
                    DataContext = null;
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Can't save that item: " + ex.Message);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            if (NavigationService.CanGoBack)
                NavigationService.GoBack();
        }

        private void ForceTextBoxDataBindingUpdate()
        {
            object focusObj = System.Windows.Input.FocusManager.GetFocusedElement();

            if (focusObj != null && focusObj is TextBox)
            {
                var binding = (focusObj as TextBox).GetBindingExpression(TextBox.TextProperty);
                binding.UpdateSource();
            }
        }
    }
}