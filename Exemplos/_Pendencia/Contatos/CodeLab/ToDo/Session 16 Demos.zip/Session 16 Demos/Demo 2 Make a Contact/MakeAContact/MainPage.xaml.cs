﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

using Microsoft.Phone.UserData;
using Microsoft.Phone.Tasks;
using Windows.Phone.PersonalInformation;

namespace MakeAContact
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        void cons_SearchCompleted(object sender, ContactsSearchEventArgs e)
        {
            try
            {
                //Bind the results to the user interface.
                ContactResultsData.DataContext = e.Results;
            }
            catch (System.Exception)
            {
                //No results
            }

            if (ContactResultsData.Items.Count > 0)
            {
                ContactResultsLabel.Text = "results loaded";
            }
            else
            {
                ContactResultsLabel.Text = "no results available";
            }
        }

        private void loadButton_Click(object sender, RoutedEventArgs e)
        {
            ContactResultsLabel.Text = "Loading";

            Contacts cons = new Contacts();

            //Identify the method that runs after the asynchronous search completes.
            cons.SearchCompleted += new EventHandler<ContactsSearchEventArgs>(cons_SearchCompleted);

            //Start the asynchronous search.
            cons.SearchAsync(String.Empty, FilterKind.None, null);
        }

        private void MakeContactButton_Click(object sender, RoutedEventArgs e)
        {
            SaveContactTask saveContact = new SaveContactTask();

            saveContact.FirstName = FirstNameTextBox.Text;
            saveContact.LastName = LastNameTextBox.Text;

            saveContact.Completed += new EventHandler<SaveContactResult>(saveContact_Completed);

            saveContact.Show();
        }

        async private void MakeCustomContactButton_Click(object sender, RoutedEventArgs e)
        {

            ContactStore store = await ContactStore.CreateOrOpenAsync();

            StoredContact contact = new StoredContact(store);
            contact.RemoteId = Guid.NewGuid().ToString();
            contact.GivenName = FirstNameTextBox.Text;
            contact.FamilyName = LastNameTextBox.Text;

            IDictionary<string, object> props = await contact.GetExtendedPropertiesAsync();
            props.Add("Password", "SecretPassword");

            await contact.SaveAsync();
        }

        void saveContact_Completed(object sender, SaveContactResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                MessageBox.Show("Saved OK");
            }
        }
    }
}