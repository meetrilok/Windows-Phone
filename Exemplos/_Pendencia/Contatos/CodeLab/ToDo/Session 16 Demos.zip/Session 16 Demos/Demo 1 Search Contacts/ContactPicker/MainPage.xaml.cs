﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.Contacts;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=391641

namespace ContactPicker
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private Contact pickedContact = null;

        private FileOpenPickerContinuationEventArgs _filePickerEventArgs = null;

        public FileOpenPickerContinuationEventArgs FilePickerEventArgs
        {
            get { return _filePickerEventArgs; }
            set { 
                _filePickerEventArgs = value;
                ContinueFileOpenPicker(_filePickerEventArgs);
            }
        }


        public MainPage()
        {
            this.InitializeComponent();

            this.NavigationCacheMode = NavigationCacheMode.Required;
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // TODO: Prepare page for display here.

            // TODO: If your application contains multiple pages, ensure that you are
            // handling the hardware Back button by registering for the
            // Windows.Phone.UI.Input.HardwareButtons.BackPressed event.
            // If you are using the NavigationHelper provided by some templates,
            // this event is handled for you.

        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            pickedContact = null;

            var contactPicker = new Windows.ApplicationModel.Contacts.ContactPicker();
            // contactPicker.CommitButtonText = "Select"; - NotImplemented
            // contactPicker.SelectionMode = ContactSelectionMode.Fields; - NotImplemented
            //contactPicker.DesiredFieldsWithContactFieldType.Add(ContactFieldType.Email);
            contactPicker.DesiredFieldsWithContactFieldType.Add(ContactFieldType.PhoneNumber);
            //contactPicker.DesiredFieldsWithContactFieldType.Add(ContactFieldType.Address);

            var contact = await contactPicker.PickContactAsync();

            if (contact != null)
            {
                string msg = "Got contact " + contact.DisplayName + " with Phone numbers: ";
                foreach (var phone in contact.Phones)
	            {
		            msg += (phone.Kind.ToString() + " " + phone.Number);
	            }
                var dlg = new Windows.UI.Popups.MessageDialog(msg);
                await dlg.ShowAsync();

                // Save for future use
                pickedContact = contact;
            }
        }

        private async void SMSButton_Click(object sender, RoutedEventArgs e)
        {
            List<string> recipients = null;

            var chatMsg = new Windows.ApplicationModel.Chat.ChatMessage
                {
                    Body = "Sending a test SMS",
                };
            //chatMsg.Recipients.Add("+44 7581 093463"); 
            chatMsg.Recipients.Add(pickedContact.Phones[0].Number);

            await Windows.ApplicationModel.Chat.ChatMessageManager.ShowComposeSmsMessageAsync(chatMsg);
        }

        private void EmailButton_Click(object sender, RoutedEventArgs e)
        {
            var email = new Windows.ApplicationModel.Email.EmailMessage
                {
                    Body = "Sending a test Email",
                };
            email.To.Add(new Windows.ApplicationModel.Email.EmailRecipient("andy.wigley@microsoft.com", "Andy Wigley"));

            Windows.ApplicationModel.Email.EmailManager.ShowComposeNewEmailAsync(email);
        }
        private void EmailWithAttachmentButton_Click(object sender, RoutedEventArgs e)
        {
            // Pick an image file
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".png");
            openPicker.PickSingleFileAndContinue();
            // App suspends here - see Sharing module for details of FileOpenPicker operation
        }
        private async void ContinueFileOpenPicker(FileOpenPickerContinuationEventArgs _filePickerEventArgs)
        {
            // Resuming processing after FileOpenPicker returns
            if (_filePickerEventArgs.Files.Count > 0)
            {
                StorageFile pickedFile = _filePickerEventArgs.Files[0];
                await pickedFile.CopyAsync(ApplicationData.Current.LocalFolder, "MyPicture.jpg", NameCollisionOption.ReplaceExisting);

                StorageFile fileToAttach = await ApplicationData.Current.LocalFolder.GetFileAsync("MyPicture.jpg");
                RandomAccessStreamReference randomAccessStreamRef =
                    RandomAccessStreamReference.CreateFromFile(fileToAttach);
                var emailAttachment =
                    new Windows.ApplicationModel.Email.EmailAttachment(fileToAttach.Name, randomAccessStreamRef);

                var email = new Windows.ApplicationModel.Email.EmailMessage
                    {
                        Body = "Sending a test Email",
                        Subject = "This test email has an attachment",
                    };
                email.Attachments.Add(emailAttachment);                   

                await Windows.ApplicationModel.Email.EmailManager.ShowComposeNewEmailAsync(email);
            }
        }
    }
}
