﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Usercontroltiles.Resources;
using System.Windows.Media.Imaging;
using System.IO.IsolatedStorage;
using System.Windows.Shapes;
using System.Windows.Media;

namespace Usercontroltiles
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

        }

        private void Pin_button_click(object sender, RoutedEventArgs e)
        {
            //Get the message to be displayed
            string textmessage = messagebox.Text;

            //Create the usercontrol instances

           

            mediumcontrol mm = new mediumcontrol();
            mm.messageblock.Text = textmessage;

            widecontrol ww = new widecontrol();
            ww.messageblock.Text = textmessage;


            //Save images to isolated storage

            Color currentAccentColorHex = (Color)Application.Current.Resources["PhoneAccentColor"];

            //For medium control
            var bitmap1 = new WriteableBitmap(336, 336);

            //Set the background
            Rectangle rr = new Rectangle();
            rr.Height = 336;
            rr.Width = 336;
            rr.Fill = new SolidColorBrush(currentAccentColorHex);
            bitmap1.Render(rr,null);
            
            bitmap1.Render(mm, null);
            bitmap1.Invalidate();

            //For wide control
            var bitmap2 = new WriteableBitmap(691, 336);

            //Set the background
            Rectangle r2 = new Rectangle();
            r2.Height = 336;
            r2.Width = 691;
            r2.Fill = new SolidColorBrush(currentAccentColorHex);
            bitmap2.Render(r2, null);

            bitmap2.Render(ww, null);
            bitmap2.Invalidate();


            string mediumfilename, widefilename, add;

            //this parameter is added to every filename to generate unique filepath for each image
            add = generateuniquestring();
            mediumfilename = "/Shared/ShellContent/" + add + "medium.jpg";
            widefilename = "/Shared/ShellContent/" + add + "large.jpg";

            var isf = IsolatedStorageFile.GetUserStoreForApplication();

            //save the medium image
            using (var stream = isf.OpenFile(mediumfilename, System.IO.FileMode.OpenOrCreate))
            {
                bitmap1.SaveJpeg(stream, 336, 366, 0, 100);
            }
            
            //save the wide image
            using (var stream = isf.OpenFile(widefilename, System.IO.FileMode.OpenOrCreate))
            {
                bitmap2.SaveJpeg(stream, 691, 366, 0, 100);
            }


            //Pin the tile
            FlipTileData fliptile = new FlipTileData()
            {
                //The uri of file path is absolute not relative
                BackgroundImage = new Uri("isostore:" + mediumfilename, UriKind.Absolute),
                WideBackgroundImage = new Uri("isostore:" + widefilename, UriKind.Absolute)
            };

            //Always provide a unique tile navigation uri to the each secondary tile that is pinned through the application
            string tileuri = string.Concat("/MainPage.xaml?", DateTime.Now.ToString());

            //Creating a new secondary flip tile on start screen having the properties as provided by the Tiledata class
            //and the navigation uri given by tileuri string member
            ShellTile.Create(new Uri(tileuri, UriKind.Relative), fliptile, true);
     

        }


        //generation of uniquestring with the help of time function
        public string generateuniquestring()
        {
            string send;
            send = DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
            return send;
        }
       
    }
}