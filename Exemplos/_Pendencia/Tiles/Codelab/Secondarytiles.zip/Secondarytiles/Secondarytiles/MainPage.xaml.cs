﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Secondarytiles.Resources;

namespace Secondarytiles
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

        }

        //Function to check whether the a tile with the following uri exist before
        private ShellTile checktile(string uri)
        {
            ShellTile shellTile = ShellTile.ActiveTiles.FirstOrDefault(tile => tile.NavigationUri.ToString().Contains(uri));
            return shellTile;
        }


        //Flip tile pin
        private void Flip_tile_click_button(object sender, RoutedEventArgs e)
        {
            //Creating a sample flip tile class
            FlipTileData fliptile = new FlipTileData()
            {
                Title = "flip tile",
                BackTitle = "back of flip tile",
                BackContent = "hello everyone",
                WideBackContent = "Have a nice day",
                Count = 4,
                SmallBackgroundImage =  new Uri("Images/small.jpg", UriKind.Relative),
                BackgroundImage =  new Uri("Images/medium.jpg", UriKind.Relative),
                WideBackgroundImage = new Uri("Images/large.jpg", UriKind.Relative)               
            };

            //Always provide a unique tile navigation uri to the each secondary tile that is pinned through the application
            string tileuri = string.Concat("/MainPage.xaml?", "id=flip");

            //check whether tile with same uri exist before or not
            ShellTile tile = checktile(tileuri);
            

            if (tile == null)
            {
                //Creating a new secondary flip tile on start screen having the properties as provided by the Tiledata class
                //and the navigation uri given by tileuri string member
                ShellTile.Create(new Uri(tileuri, UriKind.Relative), fliptile,true);
            }
        }


        //Cyclic tile pin
        private void Cyclic_tile_click(object sender, RoutedEventArgs e)
        {
            //Creating a cyclic tile class
            CycleTileData cycleTile = new CycleTileData()
            {
                Title = "cyclic tile",
                Count = 4,
                SmallBackgroundImage = new Uri("Images/small.jpg", UriKind.Relative),
                CycleImages = new Uri[]
                 {
                  new Uri("Images/cyclic1.jpg", UriKind.Relative), 
                  new Uri("Images/cyclic2.jpg", UriKind.Relative), 
                 }
            };

            //Always provide a unique tile navigation uri to the each secondary tile that is pinned through the application
            string tileuri = string.Concat("/MainPage.xaml?", "id=cyclic");

            //check whether tile with same uri exist before or not
            ShellTile tile = checktile(tileuri);

            if (tile == null)
            {
                //Creating a new secondary flip tile on start screen having the properties as provided by the Tiledata class
                //and the navigation uri given by tileuri string member
                ShellTile.Create(new Uri(tileuri, UriKind.Relative), cycleTile,true);
            }

        }

        //icon tile pin
        private void Create_iconic_tile(object sender, RoutedEventArgs e)
        {
            //Creating a iconic tile class
            IconicTileData iconic = new IconicTileData()
            {
             Title = "iconic tile",
             Count = 87,
             WideContent1 = "Battery left 87%",
             WideContent2 = "estimated time remainning",
             WideContent3 = "21 hours 24 min",
             SmallIconImage = new Uri("Images/Iconic.png", UriKind.Relative),
             IconImage = new Uri("Images/Iconic.png", UriKind.Relative),
            };

            //Always provide a unique tile navigation uri to the each secondary tile that is pinned through the application
            string tileuri = string.Concat("/MainPage.xaml?", "id=iconic");

            //check whether tile with same uri exist before or not
            ShellTile tile = checktile(tileuri);

            if (tile == null)
            {
                //Creating a new secondary flip tile on start screen having the properties as provided by the Tiledata class
                //and the navigation uri given by tileuri string member
                ShellTile.Create(new Uri(tileuri, UriKind.Relative), iconic,true);
            }

        }

        



       
    }
}