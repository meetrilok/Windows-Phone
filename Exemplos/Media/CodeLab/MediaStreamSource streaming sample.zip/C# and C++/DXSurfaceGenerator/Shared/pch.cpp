﻿//*********************************************************
//
// Copyright (c) Microsoft. All rights reserved.
//
//*********************************************************
//
// pch.cpp
// Include the standard header and generate the precompiled header.
//

#include "pch.h"
