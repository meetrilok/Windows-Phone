﻿namespace WpfApp
{
    public partial class App
    {
    }
}