// Copyright (c) Microsoft. All rights reserved.

#pragma once

#include <vccorlib.h>
#include <collection.h>
#include <ppltasks.h>

#include "Common\SuspensionManager.h"
#include "App.xaml.h"