﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Tiles.Resources;

namespace Tiles
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }


        //Function to check whether the a tile with the following id exist before
        private ShellTile checktile(string uri)
        {
            ShellTile shellTile = ShellTile.ActiveTiles.FirstOrDefault(tile => tile.NavigationUri.ToString().Contains(uri));
            return shellTile;
        }

        //create tile function
        private void Create_tile_button_click(object sender, RoutedEventArgs e)
        {
            //Creating a iconic tile class
            IconicTileData iconic = new IconicTileData()
            {
                Title = "iconic tile",
                Count = 87,
                WideContent1 = "Battery left 87%",
                WideContent2 = "estimated time remainning",
                WideContent3 = "21 hours 24 min",
                SmallIconImage = new Uri("Images/img.png", UriKind.Relative),
                IconImage = new Uri("Images/img.png", UriKind.Relative),
            };

            //Always provide a unique tile navigation uri to the each secondary tile that is pinned through the application
            string tileuri = string.Concat("/MainPage.xaml?", "id=battery");

            //check whether tile with same uri exist before or not
            ShellTile tile = checktile(tileuri);

            if (tile == null)
            {
                //Creating a new secondary flip tile on start screen having the properties as provided by the Tiledata class
                //and the navigation uri given by tileuri string member
                ShellTile.Create(new Uri(tileuri, UriKind.Relative), iconic, true);
            }
        }

        //update tile function
        private void update_button_click(object sender, RoutedEventArgs e)
        {
            //Creating a updated iconic tile class
            IconicTileData iconic = new IconicTileData()
            {
                Title = "iconic tile ",

                //updated content

                Count =75,
                WideContent1 = "Battery left 75%",
                WideContent2 = "estimated time remainning",
                WideContent3 = "16 hours 10 min",
                SmallIconImage = new Uri("Images/img.png", UriKind.Relative),
                IconImage = new Uri("Images/img.png", UriKind.Relative),
            };

            //check whether tile with given uri exist before
            ShellTile tile = checktile("battery");

            if (tile != null)
            {
                //as tile with the given id exists 
                //call the update method
                tile.Update(iconic);
            }
        }

        //Delete a tile
        private void Delete_Secondary_tile(object sender, RoutedEventArgs e)
        {
            //First find the tile with the given id
            ShellTile tile = checktile("battery");

            if (tile != null)
            {
                //call the delete method
                tile.Delete();
            }
        }

       
    }
}