MapsWP81
==============
Sample code for the blog post 
[Windows Phone 8.1 for Developers – Maps](http://www.jayway.com/2014/04/18/windows-phone-8-1-for-developers-maps/).

