GeofencingWP81
==============
Sample code for the blog post 
[Windows Phone 8.1 for Developers – Geolocation and Geofencing](http://www.jayway.com/2014/04/22/windows-phone-8-1-for-developers-geolocation-and-geofencing/).
