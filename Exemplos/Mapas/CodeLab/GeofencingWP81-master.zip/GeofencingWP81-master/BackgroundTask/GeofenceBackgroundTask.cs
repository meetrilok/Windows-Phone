﻿
using Windows.ApplicationModel.Background;

namespace BackgroundTask
{
    public sealed class GeofenceBackgroundTask : IBackgroundTask
    {
        public void Run(IBackgroundTaskInstance taskInstance)
        {
            //TODO: Add background code here
        }

    }
}
